/*****************************************************************************
 *
 *  Atmel Corporation
 *
 *  File              : main.c
 *  Compiler          : IAR EWAAVR 4.11A
 *  Revision          : $Revision: 1.0 $
 *  Date              : $Date: 27.07, 2005$
 *  Updated by        : $Author: KMe$
 *
 *  Support mail      : avr@atmel.com
 *
 *  Supported devices : This example is written for the ATtiny45.
 *
 *  AppNote           : AVR441: Fan controller.
 *
 *  Description       : Fan controller main file.
 *
 *****************************************************************************
 *
 *  NOTES ON IAR EWAVR VERSIONS PRIOR TO 4.10:
 *
 *  IAR EWAVR version 3.20C does not include support for ATtiny25, ATtiny45 or
 *  ATtiny85. Header and linker files for ATtiny45 are included with this
 *  application note. In order to be able to compile the project, please
 *  proceed as follows:
 *
 *    1.  Copy iotiny45.h from the subdirectory ATtiny25-45-85 to the
 *        include directory of EWAVR. Typically this can be found at:
 *          C:\Program Files\IAR Systems\Embedded Workbench 3.2\avr\inc
 *
 *    2.  Copy lnktiny45.xcl from the subdirectory ATtiny25-45-85 to the
 *        part description directory of EWAVR. Typically this is located at:
 *          C:\Program Files\IAR Systems\Embedded Workbench 3.2\avr\config
 *
 *    3.  Configure project options in AVREW:
 *          General - Target - Processor Configuration: select "-v1".
 *          General - Library Configuration: select "Enable bit definitions".
 *
 *  Some of the bit definitions have been changed. This source code uses the
 *  new bit definitions, found in IAR EWAVR, version 4.10. To compile with
 *  older versions of IAR EWAVR, rename the following:
 *
 *    EWAVR OLD DEFINITION | EWAVR NEW IDENTIFIER
 *   ----------------------+---------------------
 *     USI_STRT_vect       | USI_START_vect
 *     TIMER1_OVF_vect     | TIM1_OVF_vect
 *     TIMER0_OVF_vect     | TIM0_OVF_vect
 *     USISIF              | USICIF
 *     WDIE                | WDTIE
 *     EEMPE               | EEMWE
 *     EEPE                | EEWE
 *
 *  The following register definitions are invalid and cannot be used in IAR
 *  EWAVR version 4.10B (fixed in version 4.11A):
 *
 *    DEFINITION         | EXPLANATION
 *   --------------------+-----------------------------
 *    EEAR, EEARH, EEARL | Mapped to wrong I/O location
 *
 *****************************************************************************
 *
 *  NOTES ON FUSE BIT SETTINGS:
 *
 *  The following fuse bits MUST be programmed: CKSEL=0010, SUT=10
 *  The following fuse bits MAY NOT be programmed: CKOUT
 *
 *****************************************************************************
 *
 *  NOTES ON EEPROM CONTENTS:
 *
 *  The fan will not properly unless the microcontroller is able to retrieve
 *  the following information from the EEPROM: TWI node address, temperature
 *  offset and lookup table for thermal speed profile. EEPROM addresses for
 *  these variables are defined in the header file.
 *
 *  This application note comes with an example hex-file that can be loaded
 *  into the EEPROM of the target.
 *
 *****************************************************************************
 *
 *  NOTES ON USI & TWI:
 *
 *  See application notes AVR310 and AVR312 for more details.
 *
 ****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "inavr.h"

// #include "iotiny45.h"          // Use this when compiling with IAR EW 3.20
#include "ioavr.h"                // Use this when compiling with IAR EW 4.11

#include "main.h"
#include "USI_TWI_Slave.h"

/*****************************************************************************
 *  The EEAR, EEARH and EEARL register definitions are declared wrongly in
 *  file iotiny45.h, which comes with EWAVR version 4.10B. Use the below
 *  register references instead. This may change as new revisions of IAR EWAVR
 *  comes available. This issue has been fixed in version 4.11A.
 ****************************************************************************/

//SFR_W_N(0x1E, EAR, Dummy15, Dummy14, Dummy13, Dummy12, Dummy11, Dummy10, Dummy9, EAR8, EAR7, EAR6, EAR5, EAR4, EAR3, EAR2, EAR1, EAR0)


/*****************************************************************************
 *
 *  Global variables
 *
 ****************************************************************************/

struct GLOBAL_FLAGS
{
  unsigned char TempControl:1;
  unsigned char Halt:1;
  unsigned char alarmLowRPM:1;
  unsigned char alarmHighTemp:1;
  unsigned char wdClearEnable:1;
  unsigned char updateCurrentRPS:1;
  unsigned char dummy:1;
} gFlags = {1,0,0,0,0,0,0};

struct FAN_DATA
{
  unsigned char targetRPS;
  unsigned char currentRPS;
  unsigned char coilDuty;
  unsigned int  counterRPS;
  unsigned char startup;
} fan = {99,0,255,0,START_REV};

struct DEVICE_DATA
{
  signed char   T;                    // device temperature
  signed int    TOS;                  // temperature offset
  unsigned int  accT;                 // accumulated temperature readings
  unsigned char cntT;                 // counts
} device = {25,-270};

unsigned char extTCNT0 = 0;         // software extension to hardware counter

//#define DEBUG_DUTY_CYCLE
//#define DEBUG_SPEEDO_CYCLE
//#define DEBUG_MAIN_CYCLE
//#define DEBUG_TEMP_CYCLE
//#define DEBUG_OVF0_CYCLE

/*****************************************************************************
 *
 *  Main: program entry point
 *
 ****************************************************************************/

void main()
{
  init();                                   // initialise

  __enable_interrupt();
  coilActivate();                           // start turning the wheel

  while(1)
  {                                         // endless main loop
#ifdef DEBUG_MAIN_CYCLE
  USICR |= (1 << USITC);
#endif

    handleTemperature();
    handleSpeedometer();
    handleTWI();

    if (gFlags.wdClearEnable | gFlags.Halt)
    {
      asm("wdr");                           // fan is running: reset watchdog
      gFlags.wdClearEnable = 0;
    }
  }
}

/*****************************************************************************
 *
 *  Initialisation
 *
 ****************************************************************************/

void init(void)
{
  unsigned int  tmp;

  CLKPR = (1 << CLKPCE);
  CLKPR = CLK_PRESCALER;                    // set system clock prescaler

  asm("wdr");
  MCUSR = 0;
  WDTCR = (1<<WDTIE) | (1<<WDE) | (1<<WDP2) | (1<<WDP1) | (0<<WDP0);  // 1.0 s

  DDRB = (1 << PB1) | (1 << PB4);           // OC1A and OC1B control fan coils

  TCNT0 = 0;                                // start counting from zero
  TCCR0A = 0;
  TCCR0B = TC_PRESCALER;                    // start timer/counter here

  TCCR1 = (1 << COM1A1) | (1 << CS10);      // set PWM mode. CK = CLK
  GTCCR = (1 << COM1B1);                    // set PWM mode
  TCNT1 = 0;                                // start counting from zero
  OCR1A = fan.coilDuty;                     // compare match for OC1A
  OCR1B = fan.coilDuty;                     // compare match for OC1B
  OCR1C = 0xFF;                             // TOP value for PWM

  // use internal voltage reference and listen to temperature sensor (ADC4)
  ADMUX = (1 << REFS1) | (1 << MUX3)|(1 << MUX2)|(1 << MUX1)|(1 << MUX0);
  // ADC rate = CLK / (128 x 13.5) = 4630 Hz [CLK = 8 MHz, mode = auto-trigger]
  ADCSRA = (1<<ADEN)|(1<<ADSC)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
  while (ADCSRA & (1 << ADSC));             // discard first reading
  ADCSRA |= (1 << ADSC);                    // start new conversion

  PCMSK = IO_HALL;                          // pin change int on Hall toggle

  PLLCSR = (1 << PLLE);                     // enable PLL
  while (!(PLLCSR & (1 << PLOCK)));         // wait for PLL to lock
  PLLCSR = (1 << PLLE) | (1 << PCKE);       // now use PLL as t/c clock

  TIMSK = (1 << TOIE1) | (1 << TOIE0);
  GIMSK |= (1 << PCIE);

  tmp = EEPROM_read(TWI_ADDRESS);           // read address of this node
  if ((tmp > 0) & (tmp < 9))
  {
    // TWI address within range: use data from EEPROM
    USI_TWI_Slave_Initialise(tmp);          // set own TWI address

    // load temperature offset
    tmp = (EEPROM_read(TOS_ADDRESS) << 8);  // read high byte
    tmp |= EEPROM_read(TOS_ADDRESS+1);      // read low byte
    device.TOS = tmp;
  }
  else
  {
    // TWI address out of range: use defaults
    USI_TWI_Slave_Initialise(0x01);         // set default TWI address
    EEPROM_write(TWI_ADDRESS, 0x01);        // write default to EEPROM

    // Continue: assume room temperature and calibrate system
    calibrate();

    // Also: write default temperature profile to EEPROM
    for (tmp=0;tmp<64;tmp++)
      EEPROM_write(TABLE_ADDRESS + tmp, 10 + tmp);
  }

  asm("wdr");
}

/*****************************************************************************
 *
 *  Calibration. Assume ambient temperature is CALIB_TEMP, read temperature
 *  and calculate offset. Store offset in EEPROM.
 *
 ****************************************************************************/

void calibrate(void)
{
  ADCSRA |= (1 << ADSC);          // start new conversion
  while (ADCSRA & (1 << ADSC));   // wait until conversion ready

  ADCSRA |= (1 << ADSC);          // disregard & start second conversion
  while (ADCSRA & (1 << ADSC));   // wait until conversion ready

  device.TOS = ADCL;              // read temperature + offset, low byte first
  device.TOS |= (ADCH << 8);      // high byte next: Tos = temp + offset
  device.T = CALIB_TEMP + (CALIB_TEMP >> 6);  // T = k x reading (k ~= 1.016)
  device.TOS = device.TOS - device.T;         // Tos = offset

  EEPROM_write(TOS_ADDRESS, device.TOS >> 8);           // store high byte
  EEPROM_write(TOS_ADDRESS + 1, device.TOS & 0x00FF);   // store low byte
}

/*****************************************************************************
 *
 *  Activate one motor coil (check Hall-sensor for which one)
 *
 ****************************************************************************/

void coilActivate(void)
{
  if (gFlags.Halt)
    return;

  if ((PINB & IO_HALL) == 0)
  {
    // energize second coil: turn off OCR1A and turn on OCR1B (PB4)
    TCCR1 &= (0xFF - (1 << PWM1A));
    GTCCR |= (1 << PWM1B);
  }
  else
  {
    // energize first coil: turn off OCR1B and turn on OCR1A (PB1)
    GTCCR &= (0xFF - (1 << PWM1B));
    TCCR1 |= (1 << PWM1A);
  }
}

/*****************************************************************************
 *
 *  Alarm functions (not used in TWI implementation)
 *
 ****************************************************************************/

void alarmActivate(void)
{
  // alarm activation function (LED on) would go here
}

void alarmDeactivate(void)
{
  // alarm deactivation function (LED off) would go here
}

void alarmToggle(void)
{
  // alarm toggling (blinking LED) function would go here
}

/*****************************************************************************
 *
 *  Handle temperature read and update
 *
 ****************************************************************************/

void handleTemperature(void)
{
  unsigned int  tmp;

  if (!(ADCSRA & (1 << ADSC)))
  {
#ifdef DEBUG_TEMP_CYCLE
  USICR |= (1 << USITC);
#endif

    device.accT += readTemperature();
    device.cntT++;
    if (device.cntT > 64)
    {
      device.cntT = 0;
      device.T = device.accT >> 6;
      device.accT = 0;

      if (device.T > HIGH_TEMP_ALARM_LIMIT)
        gFlags.alarmHighTemp = 1;             // high temperature

      if (gFlags.TempControl)   // set target speed if in Temperature Mode
      {
        if (device.T < 10)
          tmp = 10;                 // temperatures below 10 degrees discarded
        else
          if (device.T > 73)
            tmp = 73;               // temperatures above 73 degrees discarded
          else
            tmp = device.T;
        tmp -= 10;                  // subtract 10, so index = [0,63]
        tmp += TABLE_ADDRESS;       // add to start of EEPROM lookup table
        fan.targetRPS = EEPROM_read(tmp); // look up target speed from table
      }
    }
    ADCSRA |= (1 << ADSC);    // start new conversion

#ifdef DEBUG_TEMP_CYCLE
  USICR |= (1 << USITC);
#endif
  }
}

/*****************************************************************************
 *
 *  Read device temperature
 *
 ****************************************************************************/

signed char readTemperature(void)
{
  signed int  T;

  T = ADCL;                 // read device temperature, low byte first
  T |= (ADCH << 8);         // high byte next
  T -= device.TOS;          // remove offset
  T -= (T >> 6);            // rough slope slope (k ~= 1.016)
  if (T > 127)
    return(127);            // reading saturetes at +127 degrees
  if (T < -128)
    return(-128);           // reading saturates at -128 degrees
  return(T);
}

/*****************************************************************************
 *
 *  Handle update and recording of fan speed
 *
 ****************************************************************************/

void handleSpeedometer(void)
{
  if (gFlags.updateCurrentRPS)
  {
#ifdef DEBUG_SPEEDO_CYCLE
  USICR |= (1 << USITC);
#endif

    fan.currentRPS = (T0_CLK/4) / fan.counterRPS;

    if (fan.currentRPS < LOW_RPS_ALARM_LIMIT)
      gFlags.alarmLowRPM = 1;               // low RPM
    else
      gFlags.alarmLowRPM = 0;               // normal RPM

    gFlags.updateCurrentRPS = FALSE;

#ifdef DEBUG_SPEEDO_CYCLE
  USICR |= (1 << USITC);
#endif
  }
}

/*****************************************************************************
 *
 *  Handle TWI protocol
 *
 ****************************************************************************/

void handleTWI(void)
{
  unsigned char messageBuf[MESSAGEBUF_SIZE];

  if (USI_TWI_statusReg.dataInRxBuf)
  {
    // USI has received data. Let's see what it is...
    USI_TWI_Get_Data_From_Transceiver(messageBuf,2);

    if (USI_TWI_statusReg.genAddressCall)
    {
      // Come here if it was a General Call
    }
    else
    {
      // Come here if last operation was a reception as Slave Address Match
      if (messageBuf[0] == TWI_CMD_MASTER_WRITE)
      {
        switch (messageBuf[1])
        {
          case 0:   gFlags.Halt = TRUE;                 // passivate coils
                    TCCR1 &= (0xFF - (1 << PWM1A));     // turn off PWM1A
                    GTCCR &= (0xFF - (1 << PWM1B));     // turn off PWM1B
                    break;
          case 1:   gFlags.Halt = FALSE;                // enable coils
                    gFlags.TempControl = TRUE;
                    break;
          default:  gFlags.Halt = FALSE;                // enable coils
                    gFlags.TempControl = FALSE;
                    fan.targetRPS = (messageBuf[1] & 0x7F);
        }
      }
      if (messageBuf[0] == TWI_CMD_MASTER_READ)
      {
        // master wants to know how we are doing: send temp and current RPS
        messageBuf[0] = device.T;
        messageBuf[1] = fan.currentRPS;
        USI_TWI_Start_Transceiver_With_Data(messageBuf,2);
      }
    }
  }
}

/*****************************************************************************
 *
 *  Pin change interrupt, triggered by any transition in Hall signal. Hall
 *  signal toggles four times per fan revolution.
 *
 ****************************************************************************/

#pragma vector = PCINT0_vect
__interrupt void pin_change(void)
{
  static unsigned char blink = 0;

#ifdef DEBUG_DUTY_CYCLE
  USICR |= (1 << USITC);
#endif

  coilActivate();

  TCCR0B = 0;                                 // stop counting
  fan.counterRPS = (256 * extTCNT0) + TCNT0;  // save counter data
  gFlags.updateCurrentRPS = TRUE;             // main should update reading
  TCNT0 = 0;                                  // start counting from zero
  extTCNT0 = 0;
  TCCR0B = TC_PRESCALER;                      // start counting now

  if (gFlags.Halt)
    return;                           // exit here, if fan was remote halted

  if (fan.startup > 0)
  {
    // fan still starting up
    if(--fan.startup == 0)
      alarmDeactivate();              // fan has started: now reset alarm
  }
  else
  {
    // Use fresh RPS reading to adjust coil active time
    if (fan.currentRPS < (fan.targetRPS - HYST_RPS))
    {
      // actual RPS lower than target: increase coil duty. Must be < TOP
      if (fan.coilDuty < OCR1C)
       fan.coilDuty++;
    }
    if (fan.currentRPS > (fan.targetRPS + HYST_RPS))
    {
      // actual RPS higher than target: decrease coil duty. Must be > 1
      if (fan.coilDuty > PWM_LOW)
        fan.coilDuty--;
    }

    if (blink < 2)
      blink++;
    else
    {
      blink = 0;
      if (gFlags.alarmHighTemp)
        alarmActivate();
      else
      {
        if (gFlags.alarmLowRPM)
          alarmToggle();
        else
          alarmDeactivate();
      }
    }
  }

  gFlags.wdClearEnable = 1;             // fan running: OK to clear watchdog

  if (fan.startup == 0)
  {
    OCR1A = fan.coilDuty;
    OCR1B = fan.coilDuty;
  }
  else
  {
    // no duty cycle control before fan has started
  }

#ifdef DEBUG_DUTY_CYCLE
  USICR |= (1 << USITC);
#endif
}

/*****************************************************************************
 *
 *  Timer/Counter 0 overflow handler. Extends counter by software. Triggered
 *  only when fan rotation drops below 1 / (4 x 32.768 ms) = 7.63 RPS.
 *
 ****************************************************************************/

#pragma vector = TIM0_OVF_vect
__interrupt void timer0_ovf(void)
{
#ifdef DEBUG_OVF0_CYCLE
  USICR |= (1 << USITC);
#endif

  // default overflow cycle: (256 x 1024) / 8 MHz = 32.768 ms
  if (extTCNT0 < 255)
    extTCNT0++;
  else
    fan.currentRPS = 0;               // cannot count further, reset value

#ifdef DEBUG_OVF0_CYCLE
  USICR |= (1 << USITC);
#endif
}

/*****************************************************************************
 *
 *  Watchdog timeout: rotor stopped, or rotating at virtually zero speed.
 *  Cut power to coils, wait a few seconds, then restart. If stopped by
 *  remote control, then wait for release command before restart.
 *
 ****************************************************************************/

#pragma vector = WDT_vect
__interrupt void wdt(void)
{
  TCCR1 &= (0xFF - (1 << PWM1A));     // turn off PWM1A
  GTCCR &= (0xFF - (1 << PWM1B));     // turn off PWM1B

  if (gFlags.Halt)
  {
    // don't set alarm if we were deliberately halted
  }
  else
  {
    alarmActivate();
  }
  __delay_cycles(32000000);           // a few seconds of delay before restart
  WDTCR = (1 << WDE) | (0 << WDP2) | (0 << WDP1) | (0 << WDP0);

  while (1);
}

/*****************************************************************************
 *
 *  EEPROM write operation
 *
 ****************************************************************************/

void EEPROM_write(unsigned int uiAddress, unsigned char ucData)
{
  while (EECR & (1<<EEWE));           // Wait for previous write to complete

  EECR = (0 << EEPM1) | (0 << EEPM0); // Set Programming mode

  EEARH = (uiAddress >> 8);           // NB: custom register definition
  EEARL = (uiAddress & 0xFF);         // NB: custom register definition
  EEDR = ucData;

  EECR |= (1 << EEMWE);
  EECR |= (1 << EEWE);
}

/*****************************************************************************
 *
 *  EEPROM read operation
 *
 ****************************************************************************/

unsigned char EEPROM_read(unsigned int uiAddress)
{
  while (EECR & (1<<EEWE));           // Wait for completion of previous write

  EEARH = (uiAddress >> 8);           // NB: custom register definition
  EEARL = (uiAddress & 0xFF);         // NB: custom register definition

  EECR |= (1<<EERE);

  return EEDR;
}
