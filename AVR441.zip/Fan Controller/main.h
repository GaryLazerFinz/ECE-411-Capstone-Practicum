/*****************************************************************************
*
* Atmel Corporation
*
* File              : main.h
* Compiler          : IAR EWAAVR 4.11A
* Revision          : $Revision: 1.0 $
* Date              : $Date: 27.07, 2005$
* Updated by        : $Author: KMe$
*
* Support mail      : avr@atmel.com
*
* Supported devices : This example is written for the ATtiny45.
*
* AppNote           : AVR441: Fan controller.
*
* Description       : Header file for the Fan Controller application.
*
****************************************************************************/

// #include "iotiny45.h"          // Use this when compiling with IAR EW 3.20
#include "ioavr.h"                // Use this when compiling with IAR EW 4.11

/*****************************************************************************
 * Function prototypes
 ****************************************************************************/

void main(void);
void init(void);
void calibrate(void);
void coilActivate(void);
void coilDeactivate(void);
void alarmActivate(void);
void alarmDeactivate(void);
void alarmToggle(void);
void handleTemperature(void);
signed char readTemperature(void);
void handleSpeedometer(void);
void handleTWI(void);
void EEPROM_write(unsigned int uiAddress, unsigned char ucData);
unsigned char EEPROM_read(unsigned int uiAddress);

#pragma vector = PCINT0_vect
__interrupt void pin_change(void);
#pragma vector = TIM0_OVF_vect
__interrupt void timer0_ovf(void);
#pragma vector = WDT_vect
__interrupt void wdt(void);

/*****************************************************************************
 * The following bit definitions in iotiny45.h are missing from EWAVR 4.10B.
 * These features have been fixed in version 4.11A and the following
 * definitions are therefore not required.
 ****************************************************************************/

/* TIMSK */
/*
#define OCIE1A 6
#define OCIE1B 5
#define OCIE0A 4
#define OCIE0B 3
#define TOIE1 2
#define TOIE0 1
*/

/* GIMSK */
/*
#define INT0 6
#define PCIE 5
*/

/* WDTCR */
/*
#define WDTIF 7
#define WDTIE 6
#define WDP3 5
#define WDCE 4
#define WDE 3
#define WDP2 2
#define WDP1 1
#define WDP0 0
*/

/* TCCR0B */
/*
#define FOC0A 7
#define FOC0B 6
#define WGM02 3
#define CS02 2
#define CS01 1
#define CS00 0
*/

/*****************************************************************************
 * The following bit definitions in iotiny45.h are declared wrongly in EWAVR,
 * version 4.10B. These features have been fixed in version 4.11A and the
 * following definitions are therefore not required.
 ****************************************************************************/

/* EECR */
/*
#define EEMPE 2
#define EEPE 1
*/

/*****************************************************************************
 * Fan chraracteristics, alarm limits etc.
 ****************************************************************************/

#define HIGH_TEMP_ALARM_LIMIT     45                // degrees centigrade
#define LOW_RPM_ALARM_LIMIT       600               // 10 RPS
#define LOW_RPS_ALARM_LIMIT       LOW_RPM_ALARM_LIMIT/60

#define CALIB_TEMP                25                // in degrees centigrade

// where to look up TWI node address (single byte location)
#define TWI_ADDRESS               0x00

// low byte of temperature offset value address (EEPROM) (two-byte data)
#define TOS_ADDRESS               0x01

// Start address of thermal speed profile table (64 bytes of data). The
// thermal speed profile is a lookup table for mapping RPS values versus
// temperature. The first element in the table gives the required speed of
// the fan in rotations per second at 15 degrees centigrade. The next element
// for 16 degrees, then 17, and so on up to 73 degrees. Fans usually don't
// run faster than 3000...6000 RPM, i.e. 50...100 RPS. There is also a low
// limit for how slow the fan can revolve without stalling.
#define TABLE_ADDRESS               0x10

// Define pin connections for Hall sensor, motor coils, calibration input,
// external control input and alarm output.
#define IO_HALL   (1<<PB3)
#define IO_EXT    (1<<PB0)

// Fan RPS hysteresis value in rotations per second. Firmware will not try to
// tune in closer than +/- HYST_RPS of target RPS. Small values may leave the
// fan oscillating for a long time due to mechanical latency.
#define HYST_RPS              1

// Allow this many revolutions for fan to start, before beginning to regulate.
// Maximum value is 255 (unsigned char).
#define START_REV             100

// When PWM duty cycle is too low the fan will stall. Set low limit according
// to fan dynamics. Typically, fan rotation questionable at duty cycles below
// 8...10%. This means a PWM low limit of 0.08 x 255 = 20 should be fine.
#define PWM_LOW               20

// Clock prescaler: 0 gives full 8 MHz from internal oscillator. See CLKPR.
#define CLK_PRESCALER         0

// Timer/counter 0 prescaler: default is 1024, which gives 15.625 kHz at 16 MHz
#define TC_PRESCALER          (1 << CS02) | (1 << CS00)

// Clock frequency of timer/counter 0 in hertz
#define T0_CLK                7812

// Default temperature offset: ADC reading when temperature is zero
#define T_OFFSET              270

// TWI setting
#define MESSAGEBUF_SIZE       4

// Sample TWI transmission commands
#define TWI_CMD_MASTER_WRITE 0x10
#define TWI_CMD_MASTER_READ  0x20
