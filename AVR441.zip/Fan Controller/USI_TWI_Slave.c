/*****************************************************************************
*
* Atmel Corporation
*
* File              : USI_TWI_Slave.c
* Compiler          : IAR EWAAVR 4.11A
* Revision          : $Revision: 1.71 $
* Date              : $Date: 27.07, 2005$
* Updated by        : $Author: LTWA, KMe $
*
* Support mail      : avr@atmel.com
*
* Supported devices : All device with USI module can be used.
*                     The example is written for the ATmega169, ATtiny26 & ATtiny2313
*
* AppNote           : AVR312 - Using the USI module as a TWI slave
*
* Description       : Functions for USI_TWI_receiver and USI_TWI_transmitter.
*
*
****************************************************************************/

//#include <ioavr.h>
#include <inavr.h>

//#include "iotiny45.h"
#include "USI_TWI_Slave.h"

//********** Static Variables **********//

static unsigned char TWI_slaveAddress;

static unsigned char TWI_RxBuf[TWI_RX_BUFFER_SIZE];
static unsigned char TWI_TxBuf[TWI_TX_BUFFER_SIZE];

union USI_TWI_statusReg USI_TWI_statusReg = {0};           // USI_TWI_S_statusRegister is defined in USI_TWI_Slave_config.h

struct USI_TWI_state                                 // Status byte holding flags.
{
  unsigned char addressMode:1;
  unsigned char masterReadDataMode:1;                    // masterReadDataMode = 0 is equal to "writeDataMode" = 1
  unsigned char unused:6;
} USI_TWI_state = {0};


//********** USI_TWI functions **********//

/*----------------------------------------------------------
  Initialise USI for TWI Slave mode.
----------------------------------------------------------*/
void USI_TWI_Slave_Initialise( unsigned char TWI_ownAddress )
{
  TWI_slaveAddress = TWI_ownAddress;

  PORT_USI |=  (1<<PORT_USI_SCL);                                 // Set SCL high
  PORT_USI |=  (1<<PORT_USI_SDA);                                 // Set SDA high
  DDR_USI  |=  (1<<PORT_USI_SCL);                                 // Set SCL as output
  DDR_USI  &= ~(1<<PORT_USI_SDA);                                 // Set SDA as input
  USICR    =  (1<<USISIE)|(0<<USIOIE)|                            // Enable Start Condition Interrupt. Disable Overflow Interrupt.
              (1<<USIWM1)|(0<<USIWM0)|                            // Set USI in Two-wire mode. No USI Counter overflow prior
                                                                  // to first Start Condition (potentail failure)
              (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|                // Shift Register Clock Source = External, positive edge
              (0<<USITC);
  USISR    = 0xF0;                                                // Clear all flags and reset overflow counter
}

/*----------------------------------------------------------
 Functions for filling and tapping the USI_TWI buffers.
----------------------------------------------------------*/
unsigned char USI_TWI_Start_Transceiver_With_Data( unsigned char *msg ,unsigned char msgSize )
{
  unsigned char i;

#ifdef BUFFER_CONTROL
  if ( msgSize > TWI_TX_BUFFER_SIZE )
    return (FALSE);
#endif

  if ( !USI_TWI_statusReg.dataInTxBuf )
  {
    for ( i=0; i<msgSize; i++ )
      TWI_TxBuf[i] = msg[i];
    USI_TWI_statusReg.dataInTxBuf = TRUE;
    return (TRUE);
  }
  else
    return (FALSE);
}

unsigned char USI_TWI_Get_Data_From_Transceiver( unsigned char *msg ,unsigned char msgSize )
{
  unsigned char i;

#ifdef BUFFER_CONTROL
  if ( msgSize > TWI_RX_BUFFER_SIZE )
    return (FALSE);
#endif

  if ( USI_TWI_statusReg.dataInRxBuf )
  {
    for ( i=0; i<msgSize; i++ )
      msg[i] = TWI_RxBuf[i];
    USI_TWI_statusReg.dataInRxBuf = FALSE;
    return (TRUE);
  }
  else
    return (FALSE);
}


// ********** Interrupt Handlers ********** //

/*----------------------------------------------------------
 Detects the USI_TWI Start Condition and intialises the USI
 for reception of the "TWI Address" packet.
----------------------------------------------------------*/
#pragma vector=USI_START_vect
__interrupt void USI_Start_Condition_ISR(void)
{
/* Set default starting conditions for new TWI package */
    USI_TWI_state.addressMode = TRUE;                               // Expect TWI address on buss
    DDR_USI  &= ~(1<<PORT_USI_SDA);                                 // Set SDA as input

/* Enable TWI Coutner overflow and interrupts*/
    USICR   =   (1<<USISIE)|(1<<USIOIE)|                            // Enable Overflow and Start Condition Interrupt. (Keep StartCondInt to detect RESTART)
                (1<<USIWM1)|(1<<USIWM0)|                            // Set USI in Two-wire mode.
                (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|                // Shift Register Clock Source = External, positive edge
                (0<<USITC);
    USISR   =   (1<<USICIF)|(1<<USIOIF)|(1<<USIPF)|(1<<USIDC)|      // Clear flags
                (0x0<<USICNT0);                                     // Set USI to sample 8 bits i.e. count 16 external pin toggles.

}


/*----------------------------------------------------------
 Handels all the comunication. Is disabled only when waiting
 for new Start Condition.
----------------------------------------------------------*/
#pragma vector=USI_OVF_vect
__interrupt void USI_Counter_Overflow_ISR(void)
{
    static volatile unsigned char TWI_bufPtr;

/* Inspect Address and R/W bit and set flags accordingly; ACK knowledge on address if able to comply
to the type of operation requested by the master (read or write) - depends on whether data are
available. for transmission/ if there is room for received data*/
    if ( USI_TWI_state.addressMode )                                  // If expecting address packet
    {
        /* If the address is a General Call or equal to mine, then start requested operation (R/W).*/
        if ( (USIDR == 0) || (( USIDR>>1 ) == TWI_slaveAddress) )
        {
            TWI_bufPtr = 0;                                            // Initialize Buffer to receive/transmit data
            if (USIDR == 0)
            {
                USI_TWI_statusReg.genAddressCall = TRUE;
            }
            else
            {
                USI_TWI_statusReg.genAddressCall = FALSE;
            }

            USI_TWI_state.addressMode = FALSE;                          // Use R/W DataMode from now on.
            USI_TWI_state.masterReadDataMode = ( USIDR & 0x01 );        // USIDR_LSB = R/W Mode. FALSE => masterWriteDataMode
            USIDR   =   0;                                              // Prepare ACK

            /* If the TxBuf is empty when Master is requesting data - To NACK on address just jump straight to Start Condition detection mode*/
            if ( USI_TWI_state.masterReadDataMode )
            {
                if ( !USI_TWI_statusReg.dataInTxBuf )
                {
                    USICR    =  (1<<USISIE)|(0<<USIOIE)|                // Enable Start Condition Interrupt. Disable Overflow Interrupt.
                                (1<<USIWM1)|(0<<USIWM0)|                // Set USI in Two-wire mode. No USI Counter overflow hold.
                                (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|    // Shift Register Clock Source = External, positive edge
                                (0<<USITC);
                    USISR   =   (0<<USICIF)|                            // Clear all flags but Start Condition
                                (1<<USIOIF)|
                                (1<<USIPF)|
                                (1<<USIDC)|
                                (0x0<<USICNT0);
                    return;
                }
            }
            /* if RxBuf is full when Master is sending - To NACK on address just jump straight to Start Condition detection mode*/
            else if ( USI_TWI_statusReg.dataInRxBuf )
            {
                    USICR    =  (1<<USISIE)|(0<<USIOIE)|                // Enable Start Condition Interrupt. Disable Overflow Interrupt.
                                (1<<USIWM1)|(0<<USIWM0)|                // Set USI in Two-wire mode. No USI Counter overflow hold.
                                (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|    // Shift Register Clock Source = External, positive edge
                                (0<<USITC);
                    USISR   =   (0<<USICIF)|                            // Clear all flags but Start Condition
                                (1<<USIOIF)|
                                (1<<USIPF)|
                                (1<<USIDC)|
                                (0x0<<USICNT0);
                    return;
            }
            DDR_USI |=  (1<<PORT_USI_SDA);                              // Set SDA as output
            USISR   =   (0<<USICIF)|(1<<USIOIF)|(1<<USIPF)|(1<<USIDC)|  // Clear all flags, except Start Cond
                        (0xE<<USICNT0);                                 // Set USI to shift out 1 bit
            while ( !(USISR & ( (1<<USICIF)|(1<<USIOIF) )) );           // Wait until ACK sent. (Pass if Start Cond.)
            DDR_USI &=  ~(1<<PORT_USI_SDA);                             // Set SDA as input

        }

        // If received address did not match own address - ignore package. Wait for new Start Condition */
        else
        {                                                              // Set USI in TWI Start Condition Mode
            USICR    =  (1<<USISIE)|(0<<USIOIE)|                       // Enable Start Condition Interrupt. Disable Overflow Interrupt.
                        (1<<USIWM1)|(0<<USIWM0)|                       // Set USI in Two-wire mode. No USI Counter overflow hold.
                        (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|           // Shift Register Clock Source = External, positive edge
                        (0<<USITC);
            USISR   =   (0<<USICIF)|                                   // Clear all flags but Start Condition
                        (1<<USIOIF)|
                        (1<<USIPF)|
                        (1<<USIDC)|
                        (0x0<<USICNT0);
            return;
        }
    }

    /* Address accepted - handle R/W byte and (N)ACK*/
    else
    {
        /* One or more bytes transmitted by slave (Master Read); Read NACK if
        transmission completed or ACK to continue */
        if ( USI_TWI_state.masterReadDataMode )
        {
            DDR_USI &=  ~(1<<PORT_USI_SDA);                             // Set SDA as intput
            USIDR   =   0;
            USISR   =   (0<<USICIF)|(1<<USIOIF)|(1<<USIPF)|(1<<USIDC)|  // Clear all flags, except Start Cond
                        (0xE<<USICNT0);                                 // Set USI to sample 1 bit
            while ( !(USISR & ( (1<<USICIF)|(1<<USIOIF) )) );           // Wait until (N)ACK received. (Pass if Start Cond.)
            if ( USIDR )                                                // If NACK (USIDR_LSB=1) re-init the Start Cond detector
            {
                USI_TWI_statusReg.dataInTxBuf = FALSE;
                    USICR    =  (1<<USISIE)|(0<<USIOIE)|                // Enable Start Condition Interrupt. Disable Overflow Interrupt.
                                (1<<USIWM1)|(0<<USIWM0)|                // Set USI in Two-wire mode. No USI Counter overflow hold.
                                (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|    // Shift Register Clock Source = External, positive edge
                                (0<<USITC);
                    USISR   =   (0<<USICIF)|                            // Clear all flags but Start Condition
                                (1<<USIOIF)|
                                (1<<USIPF)|
                                (1<<USIDC)|
                                (0x0<<USICNT0);
                    return;
            }

#ifdef BUFFER_CONTROL
            /* If the Master (has sent ACK and) is requesting more information then the size of TxBuf, then set OverflowFlag and terminate*/
            else
            {
                if ( TWI_bufPtr == TWI_TX_BUFFER_SIZE )                // But if the transmit buffer is full, then set Overflow flag
                {
                    USI_TWI_statusReg.TxBufOverflow = TRUE;
                                                                        // Set USI in TWI Start Condition Mode
                    USICR    =  (1<<USISIE)|(0<<USIOIE)|                // Enable Start Condition Interrupt. Disable Overflow Interrupt.
                                (1<<USIWM1)|(0<<USIWM0)|                // Set USI in Two-wire mode. No USI Counter overflow hold.
                                (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|    // Shift Register Clock Source = External, positive edge
                                (0<<USITC);
                    USISR   =   (0<<USICIF)|                            // Clear all flags but Start Condition
                                (1<<USIOIF)|
                                (1<<USIPF)|
                                (1<<USIDC)|
                                (0x0<<USICNT0);
                    return;
                }
            }
#endif
        }

        /* "masterWriteDataMode" - Slave receive. Store the
        sampled data and send an ACK to the Master.*/
        else
        {
            TWI_RxBuf[TWI_bufPtr++] = USIDR;
            USIDR   =   0;                                              // Send ACK

#ifdef BUFFER_CONTROL
            if ( TWI_bufPtr == TWI_RX_BUFFER_SIZE )                    // If the receive buffer is full, then rather send NACK.
            {
                USI_TWI_statusReg.RxBufOverflow = TRUE;
                USIDR   =   0x80;                                       // send NACK
            }
#endif
            DDR_USI |=  (1<<PORT_USI_SDA);                              // Set SDA as output
            USISR   =   (0<<USICIF)|(1<<USIOIF)|(1<<USIPF)|(1<<USIDC)|  // Clear all flags, except Start Cond
                        (0xE<<USICNT0);                                 // Set USI to shift out 1 bit
            while ( !(USISR & ( (1<<USICIF)|(1<<USIOIF) )) );           // Wait until (N)ACK sent. (Pass if Start Cond.)
            DDR_USI &=  ~(1<<PORT_USI_SDA);                             // Set SDA as intput
        }
    }

    /* If The TWI master has initiated a read cycle (slave transmit) copy data from buffer to USIDR*/
    if ( USI_TWI_state.masterReadDataMode )
    {
        USIDR   =   TWI_TxBuf[TWI_bufPtr++];                            // Put data in USI Data Register.
        DDR_USI |=  (1<<PORT_USI_SDA);                                  // Set SDA as output
        USISR   =   (0<<USICIF)|(1<<USIOIF)|(1<<USIPF)|(1<<USIDC)|      // Clear all flags, except Start Cond
                    (0x0<<USICNT0);                                     // Set USI to shift out 8 bits
    }

    // "masterWriteDataMode". I.e. prepare to sample a data byte. (Or stop condition.)
    else
    {
//        DDR_USI &=  ~(1<<PORT_USI_SDA);                                 // Set SDA as intput
        USISR   =   (0<<USICIF)|(1<<USIOIF)|(1<<USIPF)|(1<<USIDC)|      // Clear all flags, except Start Cond
                    (0xE<<USICNT0);                                     // Set USI to sample 1 bit
        while ( !(USISR & ( (1<<USICIF)|(1<<USIOIF)|(1<<USIPF) )) );    // Wait until 1 bit sampled or STOP condition. (Pass if Start Cond.)

        if ( USISR & (1<<USIPF) )                                       // If STOP Cond then set USI in START Cond Mode
        {
            USI_TWI_statusReg.dataInRxBuf = TRUE;                       // Transmition complete i.e. valid data in RxBuf
                                                                        // Set USI in TWI Start Condition Mode
            USICR    =  (1<<USISIE)|(0<<USIOIE)|                        // Enable Start Condition Interrupt. Disable Overflow Interrupt.
                        (1<<USIWM1)|(0<<USIWM0)|                        // Set USI in Two-wire mode. No USI Counter overflow hold.
                        (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|            // Shift Register Clock Source = External, positive edge
                        (0<<USITC);
            USISR   =   (0<<USICIF)|                                    // Clear all flags but Start Condition
                        (1<<USIOIF)|
                        (1<<USIPF)|
                        (1<<USIDC)|
                        (0x0<<USICNT0);
            return;
        }
        else {
            USISR   =   (0<<USICIF)|(1<<USIOIF)|(0<<USIPF)|(1<<USIDC)|  // Clear all flags, except Start Cond
                        (0x2<<USICNT0);                                 // Set USI to sample last 7 bits
        }
    }
}
