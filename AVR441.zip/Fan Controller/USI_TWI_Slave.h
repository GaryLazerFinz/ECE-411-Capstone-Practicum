/*****************************************************************************
*
* Atmel Corporation
*
* File              : USI_TWI_Slave.h
* Compiler          : IAR EWAAVR 4.11A
* Revision          : $Revision: 1.7 $
* Date              : $Date: 27.07, 2005$
* Updated by        : $Author: LTWA, KMe $
*
* Support mail      : avr@atmel.com
*
* Supported devices : This example is written for the ATtiny25/45/85, only
*
* AppNote           : AVR312 - Using the USI module as a TWI slave
*
* Description       : Header file for USI_TWI driver
*
****************************************************************************/

#include "main.h"

// Defines controlling code generation
//#define BUFFER_CONTROL

#define TWI_RX_BUFFER_SIZE 6
#define TWI_TX_BUFFER_SIZE 6

#define TRUE                1
#define FALSE               0

#define DDR_USI             DDRB
#define PORT_USI            PORTB
#define PIN_USI             PINE
#define PORT_USI_SDA        PORTB0
#define PORT_USI_SCL        PORTB2
#define PIN_USI_SDA         PINB0
#define PIN_USI_SCL         PINB2

//********** USI_TWI Prototypes **********//

void          USI_TWI_Slave_Initialise( unsigned char );
unsigned char USI_TWI_Start_Transceiver_With_Data( unsigned char *,unsigned char );
unsigned char USI_TWI_Get_Data_From_Transceiver( unsigned char *,unsigned char );

#pragma vector=USI_START_vect
__interrupt void USI_Start_Condition_ISR(void);
#pragma vector=USI_OVF_vect
__interrupt void USI_Counter_Overflow_ISR(void);

//********** Global Variables **********//

union USI_TWI_statusReg                       // Status byte holding flags.
{
    unsigned char all;
    struct
    {
        unsigned char dataInTxBuf:1;
        unsigned char dataInRxBuf:1;
        unsigned char genAddressCall:1;                        // TRUE = General call, FALSE = TWI Address;
        unsigned char RxBufOverflow:1;
        unsigned char TxBufOverflow:1;
        unsigned char unused:3;
    };
};

extern union USI_TWI_statusReg USI_TWI_statusReg;

