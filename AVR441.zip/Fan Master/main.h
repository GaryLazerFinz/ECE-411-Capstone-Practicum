// main.h

//Revisions number
#define SWHIGH  0
#define SWLOW   6

void Initialization(void);
unsigned char StateMachine(char state, unsigned char stimuli);
char BootFunc(char input);
void Delay(unsigned int millisec);
void OSCCAL_calibration(void);
unsigned char TWI_Act_On_Failure_In_Last_Transmission(unsigned char TWIerrorMsg);

#define BOOL    char

#define FALSE   0
#define TRUE    (!FALSE)
#define NULL    0

#define AUTO    3

// Macro definitions
#define sbi(port,bit)  (port |= (1<<bit))   //set bit in port
#define cbi(port,bit)  (port &= ~(1<<bit))  //clear bit in port

// Menu state machine states
#define ST_MAIN                           10
#define ST_STATUS                         20
#define ST_STATUS_FUNC                    21
#define ST_MONITOR                        30
#define ST_MONITOR_FUNC                   31
#define ST_THROTTLE                       40
#define ST_THROTTLE_FUNC                  41
#define ST_OPTIONS                        50
#define ST_OPTIONS_DISPLAY                51
#define ST_OPTIONS_DISPLAY_CONTRAST       52
#define ST_OPTIONS_DISPLAY_CONTRAST_FUNC  53

// Button definitions
#define KEY_NULL    0
#define KEY_ENTER   1
#define KEY_NEXT    2
#define KEY_PREV    3
#define KEY_PLUS    4
#define KEY_MINUS   5

// TWI definitions
#define SLAVE_ADDR  0x10

#define MESSAGEBUF_SIZE       4

#define TWI_GEN_CALL         0x00  // The General Call address is 0

// Sample TWI transmission commands
#define TWI_CMD_MASTER_WRITE 0x10
#define TWI_CMD_MASTER_READ  0x20

// Sample TWI transmission states, used in the main application.
#define SEND_DATA             0x01
#define REQUEST_DATA          0x02
#define READ_DATA_FROM_BUFFER 0x03
