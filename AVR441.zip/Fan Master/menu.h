// menu.h

__flash typedef struct
{
    unsigned char state;
    unsigned char input;
    unsigned char nextstate;
} MENU_NEXTSTATE;

__flash typedef struct
{
    unsigned char state;
    char __flash *pText;
    char (*pFunc)(char input);
} MENU_STATE;

// Menu text
__flash char MT_MAIN[]                      = "AVR441      FAN MASTER";
__flash char MT_STATUS[]                    = "SCAN";
__flash char MT_MONITOR[]                   = "SINGLE";
__flash char MT_THROTTLE[]                  = "REMOTE";
__flash char MT_OPTIONS[]                   = "Options";
__flash char MT_OPTIONS_DISPLAY[]           = "Display";
__flash char MT_OPTIONS_DISPLAY_CONTRAST[]  = "Adjust contrast";

MENU_NEXTSTATE menu_nextstate[] = {
//   STATE            INPUT       NEXT STATE
    {ST_MAIN,         KEY_PLUS,   ST_OPTIONS},
    {ST_MAIN,         KEY_MINUS,  ST_STATUS},

    {ST_STATUS,       KEY_PLUS,   ST_MAIN},
    {ST_STATUS,       KEY_NEXT,   ST_STATUS_FUNC},
    {ST_STATUS,       KEY_MINUS,  ST_MONITOR},
    {ST_STATUS,       KEY_ENTER,  ST_STATUS_FUNC},

    {ST_MONITOR,      KEY_PLUS,   ST_STATUS},
    {ST_MONITOR,      KEY_NEXT,   ST_MONITOR_FUNC},
    {ST_MONITOR,      KEY_MINUS,  ST_THROTTLE},
    {ST_MONITOR,      KEY_ENTER,  ST_MONITOR_FUNC},

    {ST_THROTTLE,     KEY_PLUS,   ST_MONITOR},
    {ST_THROTTLE,     KEY_NEXT,   ST_THROTTLE_FUNC},
    {ST_THROTTLE,     KEY_MINUS,  ST_OPTIONS},
    {ST_THROTTLE,     KEY_ENTER,  ST_THROTTLE_FUNC},

    {ST_OPTIONS,                KEY_PLUS,   ST_THROTTLE},
    {ST_OPTIONS,                KEY_NEXT,   ST_OPTIONS_DISPLAY},
    {ST_OPTIONS,                KEY_PREV,   ST_MAIN},
    {ST_OPTIONS,                KEY_MINUS,  ST_MAIN},

    {ST_OPTIONS_DISPLAY,        KEY_PLUS,   ST_OPTIONS_DISPLAY},
    {ST_OPTIONS_DISPLAY,        KEY_NEXT,   ST_OPTIONS_DISPLAY_CONTRAST},
    {ST_OPTIONS_DISPLAY,        KEY_PREV,   ST_OPTIONS},
    {ST_OPTIONS_DISPLAY,        KEY_MINUS,  ST_OPTIONS_DISPLAY},

    {ST_OPTIONS_DISPLAY_CONTRAST, KEY_ENTER,    ST_OPTIONS_DISPLAY_CONTRAST_FUNC},
    {ST_OPTIONS_DISPLAY_CONTRAST, KEY_PREV,     ST_OPTIONS_DISPLAY},

    {0,                         0,          0}
};


MENU_STATE menu_state[] = {
//   STATE                              STATE TEXT                  STATE_FUNC
    {ST_MAIN,                           MT_MAIN,                    NULL},
    {ST_STATUS,                         MT_STATUS,                  NULL},
    {ST_STATUS_FUNC,                    NULL,                       FanScan},
    {ST_MONITOR,                        MT_MONITOR,                 NULL},
    {ST_MONITOR_FUNC,                   NULL,                       FanMonitor},
    {ST_THROTTLE,                       MT_THROTTLE,                NULL},
    {ST_THROTTLE_FUNC,                  NULL,                       FanThrottle},
    {ST_OPTIONS,                        MT_OPTIONS,                 NULL},
    {ST_OPTIONS_DISPLAY,                MT_OPTIONS_DISPLAY,         NULL},
    {ST_OPTIONS_DISPLAY_CONTRAST,       MT_OPTIONS_DISPLAY_CONTRAST,NULL},
    {ST_OPTIONS_DISPLAY_CONTRAST_FUNC,  NULL,                       SetContrast},

    {0,                                 NULL,                       NULL},

};
