//*****************************************************************************
//
//  File........: Fan_functions.c
//
//  Author(s)...: ATMEL Finland
//
//  Target(s)...: ATmega169
//
//  Compiler....: IAR EWAAVR 2.30C
//
//  Description.: Fan specific functions
//
//  Revisions...: 1.0
//
//  YYYYMMDD - VER. - COMMENT                                       - SIGN.
//
//  20050211 - 1.0  - Created                                       - KM
//
//*****************************************************************************

//Functions
char FanScan(char input);
char FanMonitor(char input);
char FanThrottle(char input);
char FanNext(char input);
signed char FanTemperature(char input);
char FanSpeed(char input);
