//*****************************************************************************
//
//  File........: Fan_functions.c
//
//  Author(s)...: ATMEL Finland
//
//  Target(s)...: ATmega169
//
//  Compiler....: IAR EWAAVR 4.10B
//
//  Description.: Fan specific functions
//
//  Revisions...: 1.1
//
//  YYYYMMDD - VER. - COMMENT                                       - SIGN.
//
//  20050211 - 1.0  - Created                                       - KMe
//  20050330 - 1.1  - Draft                                         - KMe
//
//*****************************************************************************

//  Include files
#include <ioavr.h>

#include "main.h"
#include "Fan_functions.h"
#include "LCD_functions.h"
#include "USI_TWI_Master.h"
#include "BCD.h"

#define FALSE   0
#define TRUE    (!FALSE)

extern char gUSI;             //global variable from "main.c"

/****************************************************************************
*
*   Function name:  FanScan
*
*   Returns:        char ST_state (to the state-machine)
*
*   Parameters:     char input (from joystick)
*
*   Purpose:        Scan and show status of all available fans
*
*****************************************************************************/
char FanScan(char input)
{
    static char Cycle, Enter = 1;
    static signed char FanTemp;
    static unsigned char FanNumber, FanRPS;

    unsigned char CH, CL;

    Delay(100);

    if (Enter)                        // just entered from main menu?
    {
        LCD_Clear();
        LCD_UpdateRequired(TRUE, 0);
        FanNumber = 1;
        FanTemp = 0;
        FanRPS = 0;
        Cycle = 1;
        Enter = 0;
    }

    if (input == KEY_PREV)
    {
      Enter = 1;                      // start all over next time we enter
      return ST_STATUS;
    }

    switch (Cycle)
    {
      case 1:   // look for next fan
                FanNumber = FanNext(FanNumber);
                if (FanNumber)
                {
                  FanTemp = FanTemperature(FanNumber);
                  FanRPS = FanSpeed(FanNumber);
                  LCD_putc(0, 'F');
                  LCD_putc(1, 'A');
                  LCD_putc(2, 'N');
                  LCD_putc(4, '0');
                  LCD_putc(5, 48 + FanNumber);
                  LCD_UpdateRequired(TRUE, 0);
                }
                else
                {
                  FanTemp = 0;
                  FanRPS = 0;
                  LCD_putc(0, 'N');
                  LCD_putc(1, 'O');
                  LCD_putc(3, 'F');
                  LCD_putc(4, 'A');
                  LCD_putc(5, 'N');
                  LCD_UpdateRequired(TRUE, 0);
                }
                break;
      case 11:  LCD_Clear();
                LCD_UpdateRequired(TRUE, 0);
                if (FanNumber == 0)
                  Cycle = 0;
                break;
      case 12:  if (FanTemp < 0)
                {
                  CH = CHAR2BCD2(-FanTemp);
                  LCD_putc(0, '-');
                }
                else
                {
                  CH = CHAR2BCD2(FanTemp);
                  LCD_putc(0, '+');
                }
                CL = (CH & 0x0F) + '0';
                CH = (CH >> 4) + '0';
                LCD_putc(1, CH);
                LCD_putc(2, CL);
                LCD_putc(4, '.');
                LCD_putc(5, 'C');
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 22:  LCD_Clear();
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 23:  CH = CHAR2BCD2(FanRPS);
                CL = (CH & 0x0F) + '0';
                CH = (CH >> 4) + '0';
                LCD_putc(0, CH);
                LCD_putc(1, CL);
                LCD_putc(3, 'R');
                LCD_putc(4, 'P');
                LCD_putc(5, 'S');
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 33:  LCD_Clear();
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 43:  Cycle = 0;
                break;

    }
    Cycle++;

    return ST_STATUS_FUNC;
}

/****************************************************************************
*
*   Function name:  FanMonitor
*
*   Returns:        char ST_state (to the state-machine)
*
*   Parameters:     char input (from joystick)
*
*   Purpose:        Show and constantly update status of selected fan
*
*****************************************************************************/
char FanMonitor(char input)
{
    static char Cycle, Enter = 1;
    static signed char FanTemp;
    static unsigned char FanNumber, FanRPS;

    unsigned char CH, CL;

    Delay(100);

    if (Enter)                        // just entered from main menu?
    {
        LCD_Clear();
        LCD_UpdateRequired(TRUE, 0);
        FanNumber = 1;
        FanTemp = 0;
        FanRPS = 0;
        Cycle = 1;
        Enter = 0;
    }

    switch (input)
    {
        case  KEY_ENTER:
        case  KEY_PLUS:
        case  KEY_NEXT:   if (FanNumber < 8)
                            FanNumber++;
                          else
                            FanNumber = 1;      // wrap around
                          Cycle = 1;
                          break;
        case  KEY_MINUS:
        case  KEY_PREV:   FanNumber--;
                          Cycle = 1;
                          break;
    }

    if (FanNumber == 0)
    {
      Enter = 1;                      // start all over next time we enter
      return ST_MONITOR;
    }

    switch (Cycle)
    {
      case 1:   LCD_putc(0, 'F');
                LCD_putc(1, 'A');
                LCD_putc(2, 'N');
                LCD_putc(3, ' ');
                LCD_putc(4, '0');
                LCD_putc(5, 48 + FanNumber);
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 2:   FanTemp = FanTemperature(FanNumber);
                break;
      case 3:   if (FanTemp == 0)
                  FanRPS = 0;
                else
                  FanRPS = FanSpeed(FanNumber);
                break;
      case 11:  LCD_Clear();
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 12:  if (FanTemp == 0)
                {
                  LCD_putc(0, ' ');
                  LCD_putc(1, ' ');
                  LCD_putc(2, 'N');
                  LCD_putc(3, 'A');
                  LCD_putc(4, ' ');
                  LCD_putc(5, ' ');
                }
                else
                {
                  if (FanTemp < 0)
                  {
                    CH = CHAR2BCD2(-FanTemp);
                    LCD_putc(0, '-');
                  }
                  else
                  {
                    CH = CHAR2BCD2(FanTemp);
                    LCD_putc(0, '+');
                  }
                  CL = (CH & 0x0F) + '0';
                  CH = (CH >> 4) + '0';
                  LCD_putc(1, CH);
                  LCD_putc(2, CL);
                  LCD_putc(4, '.');
                  LCD_putc(5, 'C');
                }
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 22:  LCD_Clear();
                LCD_UpdateRequired(TRUE, 0);
                if (FanTemp == 0)
                  Cycle = 0;
                break;
      case 23:  CH = CHAR2BCD2(FanRPS);
                CL = (CH & 0x0F) + '0';
                CH = (CH >> 4) + '0';
                LCD_putc(0, CH);
                LCD_putc(1, CL);
                LCD_putc(3, 'R');
                LCD_putc(4, 'P');
                LCD_putc(5, 'S');
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 33:  LCD_Clear();
                LCD_UpdateRequired(TRUE, 0);
                break;
      case 43:  Cycle = 0;
                break;

    }
    Cycle++;

    return ST_MONITOR_FUNC;
}

/****************************************************************************
*
*   Function name:  FanThrottle
*
*   Returns:        char ST_state (to the state-machine)
*
*   Parameters:     char input (from joystick)
*
*   Purpose:        Remote control for all fan nodes
*
*   Display:        Fn:XX:YY
*
*****************************************************************************/
char FanThrottle(char input)
{
    static char enter = 1;
    static unsigned char FanNumber = 1, FanChange = TRUE, targetRPS = 20;

    unsigned char messageBuf[MESSAGEBUF_SIZE];
    unsigned char CH, CL, temp;

    if (enter)
    {
        LCD_Clear();
        LCD_Colon(TRUE);
        enter = 0;
    }

    if (FanNumber == 0)
    {
        enter = 1;
        FanNumber = 1;
        LCD_Colon(FALSE);
        LCD_UpdateRequired(TRUE, 0);
        return ST_THROTTLE;
    }

    if (FanChange)
    {
        LCD_Clear();
        LCD_putc(0, 'F');
        LCD_putc(1, 48 + FanNumber);
        LCD_putc(2, '-');
        LCD_putc(3, '-');
        LCD_putc(4, '-');
        LCD_putc(5, '-');
        LCD_UpdateRequired(TRUE, 0);
        FanChange = FALSE;

        gUSI = TRUE;
        messageBuf[0] = (FanNumber << TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT);
        messageBuf[1] = TWI_CMD_MASTER_READ;
        temp = USI_TWI_Start_Transceiver_With_Data(messageBuf, 2);
        messageBuf[0] = (FanNumber << TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT);
        Delay(100);
        if (USI_TWI_Start_Transceiver_With_Data(messageBuf, 2))
            targetRPS = messageBuf[1];
        else
            targetRPS = 0;
        gUSI = FALSE;
    }

    switch (input)
    {
        case  KEY_NEXT:   if (FanNumber < 8)
                            FanNumber++;
                          else
                            FanNumber = 1;      // wrap around
                          FanChange = TRUE;
                          break;
        case  KEY_PREV:   FanNumber--;
                          FanChange = TRUE;
                          break;
        case  KEY_PLUS:   if (targetRPS < 100)
                            targetRPS++;
                          break;
        case  KEY_MINUS:  if (targetRPS > 0)
                            targetRPS--;
                          break;
        case  KEY_ENTER:  if (targetRPS > 0)
                            targetRPS = 0;      // stop fan
                          else
                            targetRPS = 1;      // set temperature mode
                          break;
    }

    gUSI = TRUE;
    messageBuf[0] = (FanNumber << TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT);
    messageBuf[1] = TWI_CMD_MASTER_READ;
    temp = USI_TWI_Start_Transceiver_With_Data(messageBuf,2);
    messageBuf[0] = (FanNumber << TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT);
    Delay(200);
    if (USI_TWI_Start_Transceiver_With_Data(messageBuf,3))
    {
        CH = CHAR2BCD2(messageBuf[2]);
        CL = (CH & 0x0F) + '0';
        CH = (CH >> 4) + '0';
        LCD_putc(2, CH);
        LCD_putc(3, CL);
        switch (targetRPS)
        {
          case 0:   LCD_putc(4, 'S');
                    LCD_putc(5, 'T');
                    break;
          case 1:   LCD_putc(4, 'T');
                    LCD_putc(5, 'M');
                    break;
          default:  CH = CHAR2BCD2(targetRPS);
                    CL = (CH & 0x0F) + '0';
                    CH = (CH >> 4) + '0';
                    LCD_putc(4, CH);
                    LCD_putc(5, CL);
                    break;
        }

        // Send a Address Call, sending a command and data to the Slave
        messageBuf[0] = (FanNumber<<TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT);
        messageBuf[1] = TWI_CMD_MASTER_WRITE;
        messageBuf[2] = targetRPS;
        temp = USI_TWI_Start_Transceiver_With_Data(messageBuf, 3);
    }
    else
    {
      // Use TWI status information to detemine cause of failure and take
      // appropriate actions.
      switch (USI_TWI_Get_State_Info())
      {
        case  USI_TWI_NO_DATA:            // Transmission buffer is empty
        case  USI_TWI_DATA_OUT_OF_BOUND:  // Transmission buffer is outside SRAM space
        case  USI_TWI_UE_START_CON:       // Unexpected Start Condition
        case  USI_TWI_UE_STOP_CON:        // Unexpected Stop Condition
        case  USI_TWI_UE_DATA_COL:        // Unexpected Data Collision (arbitration)
        case  USI_TWI_MISSING_START_CON:  // Generated Start Condition not detected on bus
        case  USI_TWI_MISSING_STOP_CON:   // Generated Stop Condition not detected on bus
        case  USI_TWI_NO_ACK_ON_DATA:     // The slave did not acknowledge all data
                                          LCD_putc(2, 'E');
                                          LCD_putc(3, '0' + USI_TWI_Get_State_Info());
                                          LCD_putc(4, '-');
                                          LCD_putc(5, '-');
                                          break;
        case  USI_TWI_NO_ACK_ON_ADDRESS:  // The slave did not acknowledge the address
                                          LCD_putc(2, 'N');
                                          LCD_putc(3, 'A');
                                          LCD_putc(4, '-');
                                          LCD_putc(5, '-');
                                          break;
      }
    }
    LCD_UpdateRequired(TRUE, 0);
    gUSI = FALSE;

    return ST_THROTTLE_FUNC;
}

/****************************************************************************
*
*   Function name:  FanNext
*
*   Returns:        char ST_state (to the state-machine)
*
*   Parameters:     char input (from joystick)
*
*   Purpose:        Return TWI address number of next available fan.
*                   Zero means no fans were found.
*
*   Display:        Fn:XX:YY
*
*****************************************************************************/
char FanNext(char FanStart)
{
  unsigned char FanNumber;

  FanNumber = FanStart;

  while(1)
  {
    FanNumber++;                    // try next address
    if (FanNumber > 8)
    {
      FanNumber = 1;                // only look up addresses 1...8
      if ((FanStart < 1) | (FanStart > 8))
        return 0;                   // wrap around, no fans found
    }
    if (FanTemperature(FanNumber))
      return FanNumber;             // found one valid address, now exit
    if (FanNumber == FanStart)
      return 0;                     // wrap around: cycle complete, no fans
    Delay(50);                      // don't scan too fast: slaves need time
  }
}

/****************************************************************************
*
*   Function name:  FanTemperature
*
*   Returns:        char ST_state (to the state-machine)
*
*   Parameters:     char input (from joystick)
*
*   Purpose:        Return temperature of fan.
*                   Zero means there was an error.
*
*   Display:        Fn:XX:YY
*
*****************************************************************************/
signed char FanTemperature(char FanNumber)
{
  unsigned char messageBuf[MESSAGEBUF_SIZE];
  unsigned char utemp;
  signed char stemp;

  DDRB |= 0x01;

  gUSI = TRUE;

  messageBuf[0] = (FanNumber << TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT);
  messageBuf[1] = TWI_CMD_MASTER_READ;
  utemp = USI_TWI_Start_Transceiver_With_Data(messageBuf, 2);

  messageBuf[0] = (FanNumber << TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT);
  utemp = USI_TWI_Start_Transceiver_With_Data(messageBuf, 3);

  gUSI = FALSE;

  if (!utemp)
  {
    return 0;
  }
  else
  {
    stemp = (signed char) messageBuf[1];
    if (stemp < -99)
      stemp = -99;
    if (stemp > 99)
      stemp = 99;
    return stemp;
  }
}

/****************************************************************************
*
*   Function name:  FanSpeed
*
*   Returns:        char ST_state (to the state-machine)
*
*   Parameters:     char input (from joystick)
*
*   Purpose:        Return speed of fan.
*                   Zero means there was an error.
*
*   Display:        Fn:XX:YY
*
*****************************************************************************/
char FanSpeed(char FanNumber)
{
  unsigned char messageBuf[MESSAGEBUF_SIZE];
  unsigned char utemp;
  signed char stemp;

  gUSI = TRUE;

  messageBuf[0] = (FanNumber << TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT);
  messageBuf[1] = TWI_CMD_MASTER_READ;
  utemp = USI_TWI_Start_Transceiver_With_Data(messageBuf, 2);

  messageBuf[0] = (FanNumber << TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT);
  utemp = USI_TWI_Start_Transceiver_With_Data(messageBuf, 3);

  gUSI = FALSE;

  if (!utemp)
  {
    return 0;
  }
  else
  {
    stemp = (signed char) messageBuf[2];
    if (stemp < 0)
      stemp = 0;
    if (stemp > 99)
      stemp = 99;
    return stemp;
  }
}
