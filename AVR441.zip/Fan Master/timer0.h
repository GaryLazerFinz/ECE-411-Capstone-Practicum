
// Typedef for Timer callback function
typedef void (*TIMER_CALLBACK_FUNC) (void);

#define TIMER0_NUM_CALLBACKS        4
#define TIMER0_NUM_COUNTDOWNTIMERS  4

void Timer0_Init(void);

BOOL Timer0_RegisterCallbackFunction(TIMER_CALLBACK_FUNC pFunc);
BOOL Timer0_RemoveCallbackFunction(TIMER_CALLBACK_FUNC pFunc);


char Timer0_GetCountdownTimer(char timer);
char Timer0_AllocateCountdownTimer(void);
void Timer0_SetCountdownTimer(char timer, char value);
void Timer0_ReleaseCountdownTimer(char timer);

#pragma vector = TIMER0_COMP_vect
__interrupt void TIMER0_COMP_interrupt(void);

